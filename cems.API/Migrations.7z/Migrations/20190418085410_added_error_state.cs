﻿using System;
using cems.API.Models;
using Microsoft.EntityFrameworkCore.Migrations;

namespace cems.API.Migrations
{
    public partial class added_error_state : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<DateTime>(
                name: "CreatedTime",
                table: "ErrorLog",
                nullable: false,
                defaultValue: DateTime.Now);

            migrationBuilder.AddColumn<int>(
                name: "CurrentState",
                table: "ErrorLog",
                nullable: false,
                defaultValue: TrackedState.Undisplayed);

            migrationBuilder.AddColumn<DateTime>(
                name: "StateChangedTime",
                table: "ErrorLog",
                nullable: false,
                defaultValue: DateTime.Now);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "CreatedTime",
                table: "ErrorLog");

            migrationBuilder.DropColumn(
                name: "CurrentState",
                table: "ErrorLog");

            migrationBuilder.DropColumn(
                name: "StateChangedTime",
                table: "ErrorLog");
        }
    }
}
