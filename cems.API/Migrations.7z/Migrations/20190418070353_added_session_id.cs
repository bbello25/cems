﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace cems.API.Migrations
{
    public partial class added_session_id : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "SessionId",
                table: "ErrorLog",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "SessionId",
                table: "ErrorLog");
        }
    }
}
